import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { FinancialAnalytics } from "@/lib/financial-analytics";
import { FinancialData, RiskMetrics } from "@/types/quantum";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, TrendingDown, AlertTriangle, Shield, DollarSign, BarChart3 } from "lucide-react";

export const FinancialDashboard = () => {
  const [tickers, setTickers] = useState("SPY,QQQ,AAPL");
  const [lookbackDays, setLookbackDays] = useState(365);
  const [confidence, setConfidence] = useState(0.95);
  const [simulations, setSimulations] = useState(50000);
  const [demoMode, setDemoMode] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [financialData, setFinancialData] = useState<FinancialData | null>(null);
  const [riskMetrics, setRiskMetrics] = useState<RiskMetrics | null>(null);

  const analyzeMarket = async () => {
    setIsLoading(true);
    try {
      const tickerList = tickers.split(',').map(t => t.trim()).filter(Boolean);
      const data = FinancialAnalytics.generateSyntheticData(tickerList, lookbackDays);
      setFinancialData(data);
      
      const metrics = FinancialAnalytics.analyzeRisk(data, 10, confidence);
      setRiskMetrics(metrics);
    } finally {
      setIsLoading(false);
    }
  };

  const getPriceChartData = () => {
    if (!financialData) return [];
    
    return financialData.dates.map((date, i) => {
      const entry: any = { date };
      financialData.tickers.forEach(ticker => {
        entry[ticker] = financialData.prices[ticker][i];
      });
      return entry;
    });
  };

  const getReturnsChartData = () => {
    if (!financialData) return [];
    
    const portfolioReturns = FinancialAnalytics.calculatePortfolioReturns(financialData);
    return portfolioReturns.map((ret, i) => ({
      index: i,
      return: ret * 100, // Convert to percentage
      cumulative: portfolioReturns.slice(0, i + 1).reduce((sum, r) => sum + r, 0) * 100
    }));
  };

  const getRegimeColor = (regime: string) => {
    switch (regime) {
      case 'Low Volatility': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'Medium Volatility': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'High Volatility': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const priceData = getPriceChartData();
  const returnsData = getReturnsChartData();

  return (
    <div className="space-y-6">
      {/* Configuration */}
      <Card className="border-accent/20 bg-gradient-to-br from-card to-accent/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-primary" />
            Financial Analytics Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="tickers">Tickers (comma-separated)</Label>
              <Input
                id="tickers"
                value={tickers}
                onChange={(e) => setTickers(e.target.value)}
                placeholder="SPY,QQQ,AAPL"
              />
            </div>
            
            <div>
              <Label htmlFor="lookback">Lookback Days</Label>
              <Input
                id="lookback"
                type="number"
                value={lookbackDays}
                onChange={(e) => setLookbackDays(parseInt(e.target.value) || 365)}
                min="60"
                max="2000"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Confidence Level: {(confidence * 100).toFixed(0)}%</Label>
              <Slider
                value={[confidence]}
                onValueChange={([value]) => setConfidence(value)}
                min={0.8}
                max={0.99}
                step={0.01}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="sims">Monte Carlo Simulations</Label>
              <Input
                id="sims"
                type="number"
                value={simulations}
                onChange={(e) => setSimulations(parseInt(e.target.value) || 50000)}
                min="1000"
                max="200000"
                step="1000"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="demo"
              checked={demoMode}
              onCheckedChange={(checked) => setDemoMode(!!checked)}
            />
            <Label htmlFor="demo">Demo Mode (Synthetic Data)</Label>
          </div>

          <Button 
            onClick={analyzeMarket} 
            disabled={isLoading}
            className="w-full h-12"
          >
            {isLoading ? (
              <>
                <BarChart3 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing Market...
              </>
            ) : (
              <>
                <TrendingUp className="w-4 h-4 mr-2" />
                Fetch & Analyze Market Data
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Risk Metrics */}
      {riskMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-accent/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Value at Risk</p>
                  <p className="text-2xl font-bold text-red-400">
                    {(riskMetrics.var * 100).toFixed(2)}%
                  </p>
                </div>
                <TrendingDown className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-accent/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Conditional VaR</p>
                  <p className="text-2xl font-bold text-red-500">
                    {(riskMetrics.cvar * 100).toFixed(2)}%
                  </p>
                </div>
                <AlertTriangle className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-accent/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Sharpe Ratio</p>
                  <p className="text-2xl font-bold text-primary">
                    {riskMetrics.sharpe.toFixed(3)}
                  </p>
                </div>
                <Shield className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-accent/20">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Max Drawdown</p>
                  <p className="text-2xl font-bold text-orange-400">
                    {(riskMetrics.maxDrawdown * 100).toFixed(2)}%
                  </p>
                </div>
                <TrendingDown className="w-8 h-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Market Regime */}
      {riskMetrics && (
        <Card className="border-accent/20">
          <CardHeader>
            <CardTitle>Market Regime Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Badge className={`px-4 py-2 ${getRegimeColor(riskMetrics.regime)}`}>
                {riskMetrics.regime}
              </Badge>
              <div className="text-sm text-muted-foreground">
                Annualized Volatility: {(riskMetrics.volatility * 100).toFixed(2)}%
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Charts */}
      {financialData && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Price Chart */}
          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle>Price Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={priceData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-muted-foreground" tick={false} />
                  <YAxis className="text-muted-foreground" />
                  {financialData.tickers.map((ticker, index) => (
                    <Line
                      key={ticker}
                      type="monotone"
                      dataKey={ticker}
                      stroke={`hsl(${263 + index * 50} 70% 50%)`}
                      strokeWidth={2}
                      dot={false}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Returns Chart */}
          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle>Portfolio Returns</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={returnsData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="index" className="text-muted-foreground" tick={false} />
                  <YAxis className="text-muted-foreground" />
                  <Area
                    type="monotone"
                    dataKey="cumulative"
                    stroke="hsl(263 70% 50%)"
                    fill="hsl(263 70% 50% / 0.2)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default FinancialDashboard;