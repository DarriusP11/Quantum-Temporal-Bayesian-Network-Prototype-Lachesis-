import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { QuantumSimulator } from "@/lib/quantum-simulator";
import { QuantumConfig, QuantumResult } from "@/types/quantum";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Cell } from 'recharts';
import { Activity, Zap, TrendingUp } from "lucide-react";

interface QuantumDashboardProps {
  config: QuantumConfig;
}

export const QuantumDashboard = ({ config }: QuantumDashboardProps) => {
  const [result, setResult] = useState<QuantumResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeSimulation, setActiveSimulation] = useState<'statevector' | 'counts' | 'fidelity' | null>(null);

  const simulator = new QuantumSimulator(config);

  const runStatevector = async () => {
    setIsLoading(true);
    setActiveSimulation('statevector');
    try {
      const statevector = simulator.simulateStatevector();
      const probabilities: Record<string, number> = {};
      
      statevector.forEach((amp, i) => {
        const prob = amp.real * amp.real + amp.imag * amp.imag;
        const bitString = i.toString(2).padStart(config.numQubits, '0');
        probabilities[`|${bitString}⟩`] = prob;
      });

      setResult({ statevector, probabilities });
    } finally {
      setIsLoading(false);
      setActiveSimulation(null);
    }
  };

  const runCounts = async () => {
    setIsLoading(true);
    setActiveSimulation('counts');
    try {
      const counts = simulator.simulateCounts();
      setResult({ counts });
    } finally {
      setIsLoading(false);
      setActiveSimulation(null);
    }
  };

  const runFidelity = async () => {
    setIsLoading(true);
    setActiveSimulation('fidelity');
    try {
      const fidelity = simulator.calculateFidelity();
      setResult({ fidelity });
    } finally {
      setIsLoading(false);
      setActiveSimulation(null);
    }
  };

  const circuitVisualization = simulator.generateCircuitVisualization();

  const getChartData = () => {
    if (result?.counts) {
      return Object.entries(result.counts).map(([state, count]) => ({
        state: `|${state}⟩`,
        count,
        probability: count / config.shots
      }));
    }
    if (result?.probabilities) {
      return Object.entries(result.probabilities).map(([state, prob]) => ({
        state,
        count: Math.round(prob * config.shots),
        probability: prob
      }));
    }
    return [];
  };

  const chartData = getChartData();

  return (
    <div className="space-y-6">
      {/* Circuit Visualization */}
      <Card className="border-accent/20 bg-gradient-to-br from-card to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Quantum Circuit
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-muted/30 rounded-lg p-4 font-mono text-sm overflow-x-auto">
            {circuitVisualization.map((line, i) => (
              <div key={i} className="whitespace-pre">
                {line}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Control Buttons */}
      <div className="grid grid-cols-3 gap-4">
        <Button
          onClick={runStatevector}
          disabled={isLoading}
          className="h-16 flex flex-col gap-1"
          variant={activeSimulation === 'statevector' ? 'default' : 'outline'}
        >
          <Zap className="w-5 h-5" />
          <span>Statevector</span>
          {isLoading && activeSimulation === 'statevector' && (
            <div className="w-full mt-1">
              <Progress value={undefined} className="h-1" />
            </div>
          )}
        </Button>

        <Button
          onClick={runCounts}
          disabled={isLoading}
          className="h-16 flex flex-col gap-1"
          variant={activeSimulation === 'counts' ? 'default' : 'outline'}
        >
          <TrendingUp className="w-5 h-5" />
          <span>Measurements</span>
          {isLoading && activeSimulation === 'counts' && (
            <div className="w-full mt-1">
              <Progress value={undefined} className="h-1" />
            </div>
          )}
        </Button>

        <Button
          onClick={runFidelity}
          disabled={isLoading}
          className="h-16 flex flex-col gap-1"
          variant={activeSimulation === 'fidelity' ? 'default' : 'outline'}
        >
          <Activity className="w-5 h-5" />
          <span>Fidelity</span>
          {isLoading && activeSimulation === 'fidelity' && (
            <div className="w-full mt-1">
              <Progress value={undefined} className="h-1" />
            </div>
          )}
        </Button>
      </div>

      {/* Results Display */}
      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Metrics */}
          <Card className="border-accent/20">
            <CardHeader>
              <CardTitle>Quantum Metrics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {result.fidelity !== undefined && (
                <div className="flex justify-between items-center">
                  <span>Fidelity</span>
                  <Badge variant={result.fidelity > 0.9 ? 'default' : 'secondary'}>
                    {result.fidelity.toFixed(6)}
                  </Badge>
                </div>
              )}
              
              {result.probabilities && (
                <div>
                  <h4 className="font-semibold mb-2">State Probabilities</h4>
                  {Object.entries(result.probabilities).map(([state, prob]) => (
                    <div key={state} className="flex justify-between items-center mb-1">
                      <span className="font-mono">{state}</span>
                      <span>{(prob * 100).toFixed(2)}%</span>
                    </div>
                  ))}
                </div>
              )}

              {result.counts && (
                <div>
                  <h4 className="font-semibold mb-2">Measurement Counts</h4>
                  <div className="text-sm text-muted-foreground">
                    Total shots: {Object.values(result.counts).reduce((a, b) => a + b, 0)}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Visualization */}
          {chartData.length > 0 && (
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle>Quantum State Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="state" className="text-muted-foreground" />
                    <YAxis className="text-muted-foreground" />
                    <Bar dataKey="probability" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={index} fill={`hsl(${263 + index * 30} 70% 50%)`} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};