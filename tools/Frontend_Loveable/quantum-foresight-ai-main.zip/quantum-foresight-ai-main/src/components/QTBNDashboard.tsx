import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { QuantumTemporalBayesianNetwork } from "@/lib/qtbn-engine";
import { QTBNConfig, QTBNInferenceResult } from "@/types/qtbn";
import { FinancialData } from "@/types/quantum";
import { FinancialAnalytics } from "@/lib/financial-analytics";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar } from 'recharts';
import { Brain, TrendingUp, Zap, Target, Clock, Network } from "lucide-react";

export const QTBNDashboard = () => {
  const [qtbnEngine] = useState(() => new QuantumTemporalBayesianNetwork({
    timeHorizon: 10,
    stateSpaceSize: 4,
    observationSpace: ["volatility", "momentum", "sentiment", "volume"],
    transitionModel: "hidden_markov",
    quantumBackend: "simulator",
    inferenceMethod: "qaoa"
  }));

  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<QTBNInferenceResult | null>(null);
  const [regimeAnalysis, setRegimeAnalysis] = useState<any>(null);
  const [financialData, setFinancialData] = useState<FinancialData | null>(null);

  const runQTBNAnalysis = async () => {
    setIsRunning(true);
    try {
      // Generate synthetic financial data for analysis
      const data = FinancialAnalytics.generateSyntheticData(["SPY", "QQQ", "VIX"], 100);
      setFinancialData(data);

      // Extract market observations
      const observations = [0.15, 0.12, 0.08, 0.20]; // Volatility, momentum, sentiment, volume

      // Perform Q-TBN inference
      const inferenceResults = qtbnEngine.performInference(data, observations);
      setResults(inferenceResults);

      // Run regime detection
      const regimeResults = qtbnEngine.detectMarketRegime(data);
      setRegimeAnalysis(regimeResults);

    } finally {
      setIsRunning(false);
    }
  };

  const resetQTBN = () => {
    qtbnEngine.reset();
    setResults(null);
    setRegimeAnalysis(null);
    setFinancialData(null);
  };

  const getRegimeChartData = () => {
    if (!regimeAnalysis) return [];
    return Object.entries(regimeAnalysis.regimeProbabilities).map(([regime, probability]) => ({
      name: regime,
      value: (probability as number) * 100
    }));
  };

  const getTemporalPredictionData = () => {
    if (!results) return [];
    return results.temporalPredictions.map((pred, index) => ({
      timeStep: pred.timeStep,
      confidence: pred.predictions[Object.keys(pred.predictions)[0]] * 100,
      regime: pred.regime
    }));
  };

  const getBeliefsData = () => {
    if (!results) return [];
    return Object.entries(results.posteriorBeliefs)
      .slice(0, 8) // Show top 8 beliefs
      .map(([state, probability]) => ({
        state: state.replace(/_/g, ' '),
        probability: (probability as number) * 100
      }));
  };

  const regimeColors = {
    Bull: '#22c55e',
    Bear: '#ef4444', 
    Sideways: '#f59e0b',
    Volatile: '#8b5cf6'
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <Card className="border-accent/20 bg-gradient-to-br from-card to-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="relative">
              <Network className="w-8 h-8 text-primary" />
              <Zap className="w-4 h-4 text-accent absolute -top-1 -right-1 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Quantum Temporal Bayesian Network</h3>
              <p className="text-sm text-muted-foreground font-normal">
                Advanced temporal inference using quantum-enhanced Bayesian reasoning
              </p>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <Button 
              onClick={runQTBNAnalysis} 
              disabled={isRunning}
              className="flex-1"
            >
              {isRunning ? (
                <>
                  <Brain className="w-4 h-4 mr-2 animate-spin" />
                  Running Q-TBN Inference...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Execute Q-TBN Analysis
                </>
              )}
            </Button>
            <Button variant="outline" onClick={resetQTBN}>
              Reset Network
            </Button>
          </div>
          
          {isRunning && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Quantum inference progress</span>
                <span>Processing temporal beliefs...</span>
              </div>
              <Progress value={undefined} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Display */}
      {results && regimeAnalysis && (
        <Tabs defaultValue="regime" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="regime">Market Regime</TabsTrigger>
            <TabsTrigger value="beliefs">Belief States</TabsTrigger>
            <TabsTrigger value="temporal">Temporal Forecast</TabsTrigger>
            <TabsTrigger value="transitions">Regime Transitions</TabsTrigger>
          </TabsList>

          <TabsContent value="regime" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Current Regime */}
              <Card className="border-accent/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-primary" />
                    Current Market Regime
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div 
                      className="text-4xl font-bold mb-2"
                      style={{ color: regimeColors[regimeAnalysis.currentRegime as keyof typeof regimeColors] }}
                    >
                      {regimeAnalysis.currentRegime}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Confidence: {(regimeAnalysis.confidence * 100).toFixed(1)}%
                    </div>
                    <Progress 
                      value={regimeAnalysis.confidence * 100} 
                      className="mt-2"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    {Object.entries(regimeAnalysis.regimeProbabilities).map(([regime, prob]) => (
                      <div key={regime} className="flex justify-between items-center">
                        <span className="text-sm">{regime}</span>
                        <Badge 
                          variant="outline" 
                          style={{ 
                            borderColor: regimeColors[regime as keyof typeof regimeColors],
                            color: regimeColors[regime as keyof typeof regimeColors]
                          }}
                        >
                          {((prob as number) * 100).toFixed(1)}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Regime Distribution */}
              <Card className="border-accent/20">
                <CardHeader>
                  <CardTitle>Regime Probability Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={getRegimeChartData()}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value.toFixed(1)}%`}
                      >
                        {getRegimeChartData().map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={regimeColors[entry.name as keyof typeof regimeColors]} 
                          />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="beliefs" className="space-y-6">
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-primary" />
                  Posterior Belief States
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={getBeliefsData()} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" domain={[0, 100]} />
                    <YAxis dataKey="state" type="category" width={120} />
                    <Bar dataKey="probability" fill="hsl(263 70% 50%)" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="temporal" className="space-y-6">
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Temporal Predictions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={getTemporalPredictionData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="timeStep" />
                    <YAxis />
                    <Line 
                      type="monotone" 
                      dataKey="confidence" 
                      stroke="hsl(263 70% 50%)" 
                      strokeWidth={3}
                      dot={{ fill: 'hsl(263 70% 50%)', strokeWidth: 2, r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
                
                <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-2">
                  {results.temporalPredictions.slice(0, 5).map((pred, i) => (
                    <div key={i} className="text-center p-2 border border-accent/20 rounded">
                      <div className="text-xs text-muted-foreground">T+{pred.timeStep}</div>
                      <div 
                        className="font-semibold"
                        style={{ color: regimeColors[pred.regime as keyof typeof regimeColors] }}
                      >
                        {pred.regime}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transitions" className="space-y-6">
            <Card className="border-accent/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  Regime Transition Probabilities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {regimeAnalysis.transitions.map((transition: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-3 border border-accent/20 rounded">
                      <div className="flex items-center gap-3">
                        <span 
                          className="px-2 py-1 rounded text-xs font-semibold"
                          style={{ 
                            backgroundColor: regimeColors[transition.from as keyof typeof regimeColors] + '20',
                            color: regimeColors[transition.from as keyof typeof regimeColors]
                          }}
                        >
                          {transition.from}
                        </span>
                        <span>→</span>
                        <span 
                          className="px-2 py-1 rounded text-xs font-semibold"
                          style={{ 
                            backgroundColor: regimeColors[transition.to as keyof typeof regimeColors] + '20',
                            color: regimeColors[transition.to as keyof typeof regimeColors]
                          }}
                        >
                          {transition.to}
                        </span>
                      </div>
                      <Badge variant="outline">
                        {(transition.probability * 100).toFixed(2)}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};