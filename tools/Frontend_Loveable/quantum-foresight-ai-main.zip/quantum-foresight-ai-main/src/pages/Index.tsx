import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { QuantumControls } from "@/components/QuantumControls";
import { QuantumDashboard } from "@/components/QuantumDashboard";
import { FinancialDashboard } from "@/components/FinancialDashboard";
import { LachesisAssistant } from "@/components/LachesisAssistant";
import { QTBNDashboard } from "@/components/QTBNDashboard";
import AuthGuard from "@/components/AuthGuard";
import { useAuth } from "@/hooks/useAuth";
import { QuantumConfig, GateType } from "@/types/quantum";
import { Atom, TrendingUp, Brain, Sparkles, LogOut, User } from "lucide-react";

const DEFAULT_CONFIG: QuantumConfig = {
  numQubits: 1,
  shots: 2048,
  seed: 17,
  enableDepolarizing: false,
  enableAmplitudeDamping: false,
  enablePhaseDamping: false,
  enableCNOTNoise: false,
  depolarizingProbs: [0.01, 0.02, 0.02],
  amplitudeDampingProbs: [0.0, 0.20, 0.20],
  phaseDampingProbs: [0.04, 0.05, 0.05],
  cnotNoiseProbs: [0.02, 0.02, 0.02],
  gates: {
    step0: { 
      q0: { type: 'H' as GateType, angle: 0.5 }, 
      q1: { type: 'None' as GateType, angle: 0.0 }, 
      cnot: false 
    },
    step1: { 
      q0: { type: 'None' as GateType, angle: 0.0 }, 
      q1: { type: 'None' as GateType, angle: 0.0 }, 
      cnot: false 
    },
    step2: { 
      q0: { type: 'None' as GateType, angle: 0.0 }, 
      q1: { type: 'None' as GateType, angle: 0.0 }, 
      cnot: false 
    }
  }
};

const Index = () => {
  const [quantumConfig, setQuantumConfig] = useState<QuantumConfig>(DEFAULT_CONFIG);
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <AuthGuard>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="border-b border-accent/20 bg-gradient-to-r from-background via-accent/5 to-background">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Atom className="w-12 h-12 text-primary animate-pulse" />
                  <div className="absolute inset-0 w-12 h-12 border-2 border-primary/30 rounded-full animate-ping"></div>
                </div>
                <div>
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    Lachesis
                  </h1>
                  <p className="text-lg text-muted-foreground">
                    Quantum-Enhanced Financial Analytics & Foresight Platform
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex gap-2">
                  <Badge variant="outline" className="border-primary/30 bg-primary/10">
                    <Brain className="w-3 h-3 mr-1" />
                    AI-Powered
                  </Badge>
                  <Badge variant="outline" className="border-accent/30 bg-accent/10">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Quantum-Ready
                  </Badge>
                </div>
                
                {/* User Menu */}
                <div className="flex items-center gap-3 border-l border-accent/20 pl-4">
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-muted-foreground">
                      {user?.user_metadata?.display_name || user?.email}
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSignOut}
                    className="border-accent/30 hover:bg-accent/10"
                  >
                    <LogOut className="w-4 h-4 mr-1" />
                    Sign Out
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="quantum" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-card/50 backdrop-blur">
            <TabsTrigger value="quantum" className="flex items-center gap-2">
              <Atom className="w-4 h-4" />
              Quantum Simulation
            </TabsTrigger>
            <TabsTrigger value="finance" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Financial Analytics
            </TabsTrigger>
            <TabsTrigger value="qtbn" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Q-TBN Engine
            </TabsTrigger>
            <TabsTrigger value="sentiment" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Sentiment Analysis
            </TabsTrigger>
            <TabsTrigger value="assistant" className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              AI Assistant
            </TabsTrigger>
          </TabsList>

          <TabsContent value="quantum" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <QuantumControls 
                  config={quantumConfig} 
                  onConfigChange={setQuantumConfig} 
                />
              </div>
              <div className="lg:col-span-2">
                <QuantumDashboard config={quantumConfig} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="finance" className="space-y-6">
            <FinancialDashboard />
          </TabsContent>

          <TabsContent value="qtbn" className="space-y-6">
            <QTBNDashboard />
          </TabsContent>

          <TabsContent value="sentiment" className="space-y-6">
            <Card className="border-accent/20 bg-gradient-to-br from-card to-accent/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-primary" />
                  Sentiment Analysis Module
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center py-8 border-2 border-dashed border-accent/30 rounded-lg">
                    <Brain className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">Advanced Sentiment Processing</h3>
                    <p className="text-muted-foreground max-w-2xl mx-auto">
                      The sentiment analysis module integrates multi-source data from social media, news, and forums 
                      to provide real-time market sentiment scoring with FinBERT models, emotion detection, and 
                      cross-validation with Crunchbase fundamentals.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="border-accent/20">
                      <CardContent className="pt-6 text-center">
                        <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
                        <h4 className="font-semibold">Multi-Source Ingestion</h4>
                        <p className="text-sm text-muted-foreground">
                          Twitter/X, Reddit, LinkedIn, News APIs
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="border-accent/20">
                      <CardContent className="pt-6 text-center">
                        <Brain className="w-8 h-8 text-primary mx-auto mb-2" />
                        <h4 className="font-semibold">FinBERT Processing</h4>
                        <p className="text-sm text-muted-foreground">
                          Finance-tuned transformers with emotion detection
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="border-accent/20">
                      <CardContent className="pt-6 text-center">
                        <Sparkles className="w-8 h-8 text-accent mx-auto mb-2" />
                        <h4 className="font-semibold">QTBN Integration</h4>
                        <p className="text-sm text-muted-foreground">
                          Sentiment as quantum belief network nodes
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assistant" className="space-y-6">
            <LachesisAssistant />
          </TabsContent>
        </Tabs>
        </div>
      </div>
    </AuthGuard>
  );
};

export default Index;
